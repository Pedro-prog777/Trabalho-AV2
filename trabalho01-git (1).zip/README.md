# Trabalho 01 - Git/GitHub

Este repositório contém o primeiro trabalho da disciplina.

## Arquivos

- `hello_world.py`: Script em Python que imprime "Hello, World!".
- `README.md`: Documento com informações do projeto.

## Autor
Pedro-prog777
